var express = require('express');
var router = express.Router();
var productController = require('../../../controllers/productController');
var Ticket = require('../../../models/Ticket');
var Product = require('../../../models/Product');
var User = require('../../../models/User');
var helpers = require('../../../helper/Departments');
var auth = require('../../../Middlewares/authentication')
var AdminAuth = require('../../../Middlewares/admin')
var logController = require('../../../controllers/logController');
var logAction = require('../../../helper/LogActions');
var Log = require('../../../models/Log');
var Comment = require('../../../models/Comment');
/* GET home page. */
router.all('/*', AdminAuth.AdminAuthicated, (req, res, next) => {
    req.app.locals.layout = 'layouts/backUsers/app';
    next();
});
router.get('/products', function (req, res, next) {
    Product.find({}).then(result => {
        res.render('backUsers/admin/products', {title: 'Express', products: result});
    })
});
router.get('/products/delete/:id', function (req, res, next) {

    Product.findByIdAndDelete({_id: req.params.id}).then(result => {

        let LogName = 'تم مسح  المنتج  رقم ';
        let Model = 'Product';
        logController.addLog(LogName, req.user.name, Model, result.id, logAction.delete, req.user.email);
        res.redirect('/admin/products');
    })
});
router.post('/products/update/:id', function (req, res, next) {
    console.log(req.params.id)
    Product.findByIdAndUpdate({_id: req.params.id}, {
        $set: {
            enName: req.body.enname,
            arName: req.body.arname
        }
    }).then(result => {
        let LogName = 'تم تعديل  المنتج  رقم ';
        let Model = 'Product';
        logController.addLog(LogName, req.user.name, Model, result.id, logAction.edit, req.user.email);
        res.redirect('/admin/products');
    })
});
router.post('/products/create', function (req, res, next) {
    product = productController.addProduct(req.body.enname, req.body.arname, req.user);
    product.then(result => {
        res.writeHead(200, {'Content-Type': 'application/json'});
        res.end(JSON.stringify(result));
    })
});
router.get('/tickets/all', function (req, res, next) {

    if (req.user.role === 'stuff') {
        Ticket.find({
            $and: [{
                department: {$in: req.user.departments},
                product: {$in: req.user.products},
                status: 'open',
                workedBy: {$exists: false},
            }]
        }).populate('product').then(tickets => {
            Ticket.find({
                $and: [{
                    department: {$in: req.user.departments},
                    product: {$in: req.user.products},
                    status: 'open',
                    workedBy: req.user.id,
                }]
            }).populate('product').then(MyTickets => {
                res.render('backUsers/admin/tickets', {
                    title: 'Express',
                    tickets: tickets,
                    MyTickets: MyTickets,
                    departments: helpers.departments
                });
            });

        });
    }
    else {
        Ticket.find({}).populate('product').then(tickets => {

            res.render('backUsers/admin/tickets', {
                title: 'Express',
                tickets: tickets,
                departments: helpers.departments
            });
        });
    }

});
router.get('/ticket/view/:id', function (req, res, next) {
    Ticket.findById({_id: req.params.id}).populate('product').populate('workedBy').then(ticket => {
        Comment.find({ticket: req.params.id}).populate('user').then(comments => {
            User.find({
                $and: [{
                    departments: {$in: [ticket.department]},
                    products: {$in: [ticket.product]},
                    role: 'stuff',
                }]
            }).then(stuff => {
                res.render('backUsers/admin/viewTicket', {
                    ticket: ticket,
                    departments: helpers.departments,
                    comments: comments,
                    stuff: stuff
                });
            })

        })

    });
});
router.get('/allUsers', function (req, res, next) {
    User.find({}).then(users => {
        res.render('backUsers/admin/users', {users: users});
    })
});
router.get('/adminDashboard', function (req, res, next) {
    Ticket.find({}).then(tickets => {
        Ticket.find({status: 'closed'}).then(closedTickets => {
            User.find({}).then(users => {
                Log.find({}).then(logs => {
                    Comment.find({}).then(comments => {
                        res.render('backUsers/admin/adminDashboard', {
                            allTickets: Object.keys(tickets).length,
                            closedTickets: Object.keys(closedTickets).length,
                            users: Object.keys(users).length,
                            comments: Object.keys(comments).length,
                            logs: logs,
                            logAction: logAction
                        });
                    })

                });

            });

        })
    })


});
router.get('/myAccount', function (req, res, next) {
    Ticket.find({workedBy: req.user.id}).populate('product').then(myTickets => {
        Ticket.find({$and: [{workedBy: req.user.id}, {status: 'closed'}]}).then(closedTickets => {
            Ticket.find({}).then(allTickets => {
                res.render('backUsers/admin/myAccount', {
                    allTickets: Object.keys(allTickets).length,
                    myTickets: Object.keys(myTickets).length,
                    closedTickets: Object.keys(closedTickets).length,
                    tickets: myTickets,
                });
            })
        })
    })


});

module.exports = router;