module.exports = {

    departments: {0: 'support', 1: 'developments'},

};
