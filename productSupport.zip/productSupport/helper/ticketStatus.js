module.exports = {
    ticketStatus: {0: 'open', 1: 'closed'}
};