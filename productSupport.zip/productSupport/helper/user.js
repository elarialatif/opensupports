module.exports = {
    userTypes: {0: 'admin', 1: 'stuff', 2: 'user'}
};