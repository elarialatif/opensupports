module.exports = {

    assign: 'assign',
    edit: 'edit',
    create: 'create',
    commented: 'commented',
    reopened: 'reopened',
    closed: 'closed',
    unassigned: 'unassigned',
    delete: 'delete',
};
